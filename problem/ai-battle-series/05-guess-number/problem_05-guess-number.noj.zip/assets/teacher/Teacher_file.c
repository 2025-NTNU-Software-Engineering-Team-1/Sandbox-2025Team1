#include <stdio.h>
#include <string.h>

int main(void) {
    FILE *fp = fopen("testcase.in", "r");
    if (!fp) {
        return 1;
    }

    int n = 0;
    int secret = 0;
    int max_guess = 0;
    int count = fscanf(fp, "%d %d %d", &n, &secret, &max_guess);
    fclose(fp);
    if (count < 2) {
        return 1;
    }
    if (max_guess <= 0) {
        max_guess = 20;
    }

    printf("%d\n", n);
    fflush(stdout);

    int attempts = 0;
    int guessed = 0;
    while (attempts < max_guess) {
        char cmd[16] = {0};
        int value = 0;
        if (scanf("%15s %d", cmd, &value) != 2) {
            break;
        }
        attempts++;
        if (strcmp(cmd, "guess") != 0) {
            break;
        }
        if (value == secret) {
            printf("CORRECT\n");
            fflush(stdout);
            guessed = 1;
            break;
        } else if (value < secret) {
            printf("HIGHER\n");
            fflush(stdout);
        } else {
            printf("LOWER\n");
            fflush(stdout);
        }
    }

    FILE *out = fopen("Check_Result", "w");
    if (!out) {
        return 1;
    }
    if (guessed) {
        fprintf(out, "STATUS: AC\nMESSAGE: ok\n");
    } else {
        fprintf(out, "STATUS: WA\nMESSAGE: guess failed\n");
    }
    fclose(out);
    return 0;
}
