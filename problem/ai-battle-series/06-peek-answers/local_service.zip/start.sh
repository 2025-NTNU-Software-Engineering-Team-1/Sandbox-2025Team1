#!/bin/sh
set -e

exec python3 /app/server.py
