#!/usr/bin/env python3
"""Custom Scorer for LIS (Problem 9)

- Base score: 80 * (AC cases / total cases)
- Time bonus: <50ms +20, <200ms +10, <500ms +5
- Late penalty: 5 points per hour, max 50
"""
import json
import sys


def calculate_score(data):
    tasks = data.get("tasks", [])
    stats = data.get("stats", {})
    late_seconds = data.get("lateSeconds", 0) or 0

    total_cases = 0
    passed_cases = 0
    for task in tasks:
        results = task.get("results", []) if isinstance(task, dict) else task
        total_cases += len(results)
        passed_cases += sum(1 for r in results if isinstance(r, dict) and r.get("status") == "AC")

    base_score = 0
    if total_cases > 0:
        base_score = (passed_cases / total_cases) * 80

    avg_time = stats.get("avgRunTime", 0) or 0
    if avg_time < 50:
        time_bonus = 20
    elif avg_time < 200:
        time_bonus = 10
    elif avg_time < 500:
        time_bonus = 5
    else:
        time_bonus = 0

    late_hours = max(0.0, float(late_seconds)) / 3600.0
    late_penalty = min(50, late_hours * 5)

    final_score = base_score + time_bonus - late_penalty
    if final_score < 0:
        final_score = 0
    if final_score > 100:
        final_score = 100

    return {
        "score": int(round(final_score)),
        "message": (
            f"base={base_score:.1f}, time_bonus={time_bonus}, late_penalty={late_penalty:.1f}"
        ),
        "breakdown": {
            "base": base_score,
            "timeBonus": time_bonus,
            "latePenalty": late_penalty,
        },
    }


if __name__ == "__main__":
    try:
        payload = json.load(sys.stdin)
        result = calculate_score(payload)
        print(json.dumps(result, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"score": 0, "message": f"Scorer Error: {e}", "breakdown": {}}, ensure_ascii=False))
        sys.exit(1)
