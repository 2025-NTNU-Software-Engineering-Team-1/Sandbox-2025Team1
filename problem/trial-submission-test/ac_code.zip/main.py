# AC solution for trial submission test
# Reads two numbers and prints their sum
a, b = map(int, input().split())
print(a + b)

