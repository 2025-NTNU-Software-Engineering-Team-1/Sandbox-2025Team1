// Student implementation is injected into this file during build.
long long add(long long a, long long b);
