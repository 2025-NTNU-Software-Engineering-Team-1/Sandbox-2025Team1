#include <stdio.h>
#include "function.h"

int main(void) {
    long long a, b;
    if (scanf("%lld %lld", &a, &b) != 2) {
        return 0;
    }
    printf("%lld
", add(a, b));
    return 0;
}
