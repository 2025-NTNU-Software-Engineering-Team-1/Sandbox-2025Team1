// This file will be replaced by student submission code.
// Students should provide the implementation of `int add(int a, int b);`
